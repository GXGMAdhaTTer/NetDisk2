#ifndef __TASK_H__
#define __TASK_H__

#include <functional>

using std::function;

using Task = function<void()>;

#endif
