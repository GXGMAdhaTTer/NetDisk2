#ifndef __WEBPAGE_H__
#define __WEBPAGE_H__

class WebPage {
public:

private:

};

#endif

