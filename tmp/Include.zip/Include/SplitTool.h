#ifndef __SPLITTOOL_H__
#define __SPLITTOOL_H__

#include "Configuration.h"
#include <cppjieba/Jieba.hpp>
#include <limonp/StringUtil.hpp>
#include <vector>
#include <string>

using namespace cppjieba;

using std::vector;
using std::string;

class SplitTool {
public:
    virtual vector<string> cut(const string&) = 0;
    virtual ~SplitTool() = 0;
};

class CppJieba
    : public SplitTool {
public:
    CppJieba();

    vector<string> cut(const string&) override;

private:
    const string DICT_PATH = Configuration::getInstance()->getPath("DICT_PATH");
    const string HMM_PATH = Configuration::getInstance()->getPath("HMM_PATH");
    const string USER_DICT_PATH = Configuration::getInstance()->getPath("USER_DICT_PATH");
    const string IDF_PATH = Configuration::getInstance()->getPath("IDF_PATH");
    const string STOP_WORD_PATH = Configuration::getInstance()->getPath("STOP_WORD_PATH");

    Jieba _jieba;
};

#endif
