#ifndef __PAGELIB_H__
#define __PAGELIB_H__

#include "DirScanner.h"
#include "FileProcessor.h"
#include <utility>
#include <map>

using std::pair;
using std::map;

class PageLib {
public:
    PageLib(const string &);

    void create();
    void store();
private:
    DirScanner _dirScanner;
    FileProcessor _fileProcessor;

    /* vector<WebPage> _pageList; */


    map<int, pair<int, int>> _offsetLib; //存放每篇文档在网页库的位置信息
};

#endif

