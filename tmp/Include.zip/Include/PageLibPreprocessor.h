#ifndef __PAGELIBPREPROCESSOR_H__
#define __PAGELIBPREPROCESSOR_H__

#include "WebPage.h"
#include <vector>

using std::vector;

class PageLibPreprocessor {
public:

private:
    vector<WebPage> _pageList;

};


#endif

