#ifndef __CONFIGURATION_H__
#define __CONFIGURATION_H__

#include <string.h>
#include <unistd.h>
#include <string>
#include <fstream>
#include <sstream>
#include <unordered_map>

using std::string;
using std::unordered_map;
using std::ifstream;
using std::stringstream;

class Configuration {
public:
    static Configuration* getInstance() {
        if (_pInstance == nullptr) {
            _pInstance = new Configuration();
        }
        return _pInstance;
    }

    void initConfig();

    void showConfig();

    static void destroy() {
        if (_pInstance) {
            delete _pInstance;
            _pInstance = nullptr;
        }
    }

    static void print() {
        _pInstance->showConfig();
    }

    string getPath(const string& item) {
        return _configs[item];
    }

    unordered_map<string, string>& getConfigMap();
    
private:
    Configuration(const string& filePath = "../conf/myconf.conf");
    ~Configuration() {}

    static Configuration* _pInstance;
    string _configFilePath;
    unordered_map<string, string> _configs;
};


#endif

