#ifndef __FILEPROCESSOR_H__
#define __FILEPROCESSOR_H__

#include <string>
using std::string;

class FileProcessor {
public:
    void process(const string& filename);

private:
    string _titleFeature;
};

#endif

